
def search(x, seq):
    left, right = 0, len(seq) - 1
    while left <= right:
        mid = (left + right) // 2
        if x < seq[mid]:
            right = mid - 1
        elif x > seq[mid]:
            left = mid + 1
        else:
            return mid
    return left

