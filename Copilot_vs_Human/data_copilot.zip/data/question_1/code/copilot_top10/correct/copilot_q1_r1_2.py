
def search (x, seq):
    """ Takes in a value x and a sorted sequence seq, and returns the
        position that x should go to such that the sequence remains sorted. otherwise, return the length of the sequence """
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        return 0 if x < seq[0] else 1
    else:
        mid = len(seq) // 2
        if seq[mid] == x:
            return mid
        elif seq[mid] > x:
            return search(x, seq[:mid])
        else:
            return mid + search(x, seq[mid:])

