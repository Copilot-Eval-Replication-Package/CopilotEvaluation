
def search (x, seq):
    """ Takes in a value x and a sorted sequence seq, and returns the
        position that x should go to such that the sequence remains sorted. otherwise, return the length of the sequence """
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if x < seq[0]:
            return 0
        else:
            return 1
    else:
        if x < seq[0]:
            return 0
        elif x > seq[-1]:
            return len(seq)
        else:
            i = 0
            while x > seq[i]:
                i += 1
            return i

