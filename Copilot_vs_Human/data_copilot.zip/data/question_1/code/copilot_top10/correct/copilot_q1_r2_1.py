
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif x < seq[0]:
        return 0
    elif x > seq[-1]:
        return len(seq)
    else:
        left, right = 0, len(seq)
        while left < right:
            mid = (left + right) // 2
            if seq[mid] == x:
                return mid
            elif seq[mid] < x:
                left = mid + 1
            else:
                right = mid
        return left

