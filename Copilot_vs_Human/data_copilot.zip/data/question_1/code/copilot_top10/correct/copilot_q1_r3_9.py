
def search(x, seq):
    if len(seq) == 0:
        return 0
    for i, v in enumerate(seq):
        if x <= v:
            return i
    return len(seq)

