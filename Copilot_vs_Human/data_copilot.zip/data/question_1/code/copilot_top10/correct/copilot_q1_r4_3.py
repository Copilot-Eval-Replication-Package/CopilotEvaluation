
def search(x, seq):
    """ Takes in a value x and a sorted sequence seq, and returns the
        position that x should go to such that the sequence remains sorted """
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if seq[0] < x:
            return 1
        else:
            return 0
    else:
        mid = len(seq) // 2
        if seq[mid] < x:
            return mid + search(x, seq[mid:])
        else:
            return search(x, seq[:mid])

