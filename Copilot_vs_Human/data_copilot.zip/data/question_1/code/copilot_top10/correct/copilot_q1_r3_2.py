
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if x < seq[0]:
            return 0
        else:
            return 1
    else:
        mid = len(seq) // 2
        if x <= seq[mid]:
            return search(x, seq[:mid])
        else:
            return mid + search(x, seq[mid:])

