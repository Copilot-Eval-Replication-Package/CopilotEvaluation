
def search(x, seq):
    """ Takes in a value x and a sorted sequence seq, and returns the
        position that x should go to such that the sequence remains sorted """
    if len(seq) == 0:
        return 0
    if len(seq) == 1:
        return 1 if seq[0] < x else 0
    if seq[-1] < x:
        return len(seq)
    if seq[0] >= x:
        return 0
    if seq[-1] <= x:
        return len(seq) - 1
    l = 0
    r = len(seq) - 1
    while l + 1 < r:
        m = (l + r) // 2
        if seq[m] < x:
            l = m
        else:
            r = m
    if seq[l] >= x:
        return l
    if seq[r] >= x:
        return r
    assert (False)

