
def search(x, seq):
    low = 0
    high = len(seq) - 1
    while low <= high:
        mid = (low + high) // 2
        if x < seq[mid]:
            high = mid - 1
        elif x > seq[mid]:
            low = mid + 1
        else:
            return mid
    return low

