
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        return 0 if x <= seq[0] else 1
    else:
        mid = len(seq) // 2
        if seq[mid] == x:
            return mid
        elif seq[mid] < x:
            return mid + search(x, seq[mid:])
        else:
            return search(x, seq[:mid])

