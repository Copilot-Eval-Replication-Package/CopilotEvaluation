
def search (x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if seq[0] < x:
            return 1
        else:
            return 0
    else:
        if seq[-1] < x:
            return len(seq)
        else:
            if seq[0] > x:
                return 0
            else:
                for i in range(1, len(seq)):
                    if seq[i-1] < x < seq[i]:
                        return i
                return len(seq)

