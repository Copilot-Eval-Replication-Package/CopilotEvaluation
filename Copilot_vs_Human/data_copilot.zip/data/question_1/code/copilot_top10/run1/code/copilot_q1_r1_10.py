
def search (x, seq):
    if len(seq) == 0:
        return 0
    if x == seq[0]:
        return 0
    if x == seq[-1]:
        return len(seq)
    if x < seq[0]:
        return 0
    if x > seq[-1]:
        return len(seq)
    mid = int(len(seq)/2)
    if x < seq[mid]:
        return search(x, seq[:mid])
    else:
        return mid + search(x, seq[mid:])


