
def search (x, seq):
    """ Takes in a value x and a sorted sequence seq, and returns the
    position that x should go to such that the sequence remains sorted. otherwise, return the length of the sequence """
    if len(seq) == 0:
        return 0
    elif seq[0] > x:
        return 0
    elif seq[-1] < x:
        return len(seq)
    else:
        for i in range(len(seq)):
            if seq[i] > x:
                return i

