
def search (x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if seq[0] == x:
            return 0
        else:
            return 1
    else:
        if seq[0] == x:
            return 0
        elif seq[-1] == x:
            return len(seq)
        else:
            mid = int(len(seq)/2)
            if x < seq[mid]:
                return search(x, seq[:mid])
            elif x > seq[mid]:
                return mid + search(x, seq[mid:])
            else:
                return mid

