
def search(x, seq):
    pos = bisect.bisect_left(seq, x)
    if pos == len(seq):
        return pos-1
    elif seq[pos] == x:
        return pos
    else:
        return pos+1

