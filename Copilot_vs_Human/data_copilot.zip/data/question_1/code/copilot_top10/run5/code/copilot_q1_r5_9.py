
def search(x, seq):
    if seq == []:
        return 0
    if x < seq[0]:
        return 0
    if x > seq[-1]:
        return len(seq)
