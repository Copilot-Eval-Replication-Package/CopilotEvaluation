
def search(x, seq):
    if x < seq[0]:
        return 0
    if x > seq[-1]:
        return len(seq)
    l = 0
    r = len(seq)
    while l < r:
        m = (l + r) // 2
        if seq[m] < x:
            l = m + 1
        else:
            r = m
    return l

