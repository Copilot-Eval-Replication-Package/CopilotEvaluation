
def search(x, seq):
    # assert(is_sorted(seq))
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if x >= seq[0]:
            return 1
        else:
            return 0
    else:
        mid = len(seq) // 2
        if x >= seq[mid]:
            return search(x, seq[mid:]) + mid
        else:
            return search(x, seq[:mid])

