
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        return 0 if x <= seq[0] else 1
    else:
        if x <= seq[0]:
            return 0
        elif x >= seq[-1]:
            return len(seq)
        else:
            # binary search
            l = 0
            r = len(seq)
            while l <= r:
                m = (l + r) // 2
                if x <= seq[m]:
                    r = m - 1
                else:
                    l = m + 1
            return l

