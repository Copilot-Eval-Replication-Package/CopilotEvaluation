
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        return 1 if seq[0] > x else 0
    else:
        mid = len(seq)//2
        if seq[mid] < x:
            return search(x, seq[mid+1:]) + mid + 1
        else:
            return search(x, seq[:mid])

