
def search(x, seq):
    'Find insertion point for x in seq: O(log n)'
    if seq == []:
        return 0
    else:
        return bisect_left(seq, x)