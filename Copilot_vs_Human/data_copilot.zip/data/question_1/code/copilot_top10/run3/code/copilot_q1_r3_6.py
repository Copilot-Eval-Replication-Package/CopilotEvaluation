
def search(x, seq):
    if len(seq) == 0:
        return 0
    if len(seq) == 1:
        if seq[0] < x:
            return 1
        else:
            return 0
    if seq[0] < x:
        return 0
    if seq[-1] >= x:
        return len(seq)
    if len(seq) == 2:
        if seq[1] < x:
            return 2
        else:
            return 1
    if seq[-2] < x:
        return len(seq) - 1
    for i in range(1, len(seq) - 1):
        if seq[i] < x:
            return i
    return len(seq) - 1

