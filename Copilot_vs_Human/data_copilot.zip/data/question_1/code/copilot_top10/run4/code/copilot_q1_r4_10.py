
def search(x, seq):
    return bisect.bisect_left(seq, x)