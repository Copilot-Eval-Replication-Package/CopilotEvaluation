
def search(x, seq):
    if x < seq[0]:
        return 0
    if x > seq[-1]:
        return len(seq)
    low = 0
    high = len(seq)
    while low < high:
        mid = (low + high) // 2
        if x < seq[mid]:
            high = mid
        else:
            low = mid + 1
    return low

