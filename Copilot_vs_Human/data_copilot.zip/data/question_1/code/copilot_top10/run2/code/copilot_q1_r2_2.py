
def search(x, seq):
    i = 0
    j = len(seq) - 1
    while i < j:
        m = (i + j) // 2
        if seq[m] < x:
            i = m + 1
        else:
            j = m
    return i

