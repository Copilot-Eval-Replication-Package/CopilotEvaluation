
def search(x, seq):
    if x < seq[0]:
        return 0
    elif x > seq[-1]:
        return len(seq)
    else:
        i = 0
        j = len(seq) - 1
        while i + 1 < j:
            m = (i + j) // 2
            if seq[m] < x:
                i = m
            else:
                j = m
        if seq[i] == x:
            return i
        else:
            return j

