
def search(x, seq):
    if len(seq) == 0:
        return 0
    elif len(seq) == 1:
        if seq[0] > x:
            return 0
        else:
            return 1
    else:
        mid = len(seq) // 2
        if seq[mid] > x:
            return search(x, seq[:mid])
        else:
            return mid + search(x, seq[mid:])

