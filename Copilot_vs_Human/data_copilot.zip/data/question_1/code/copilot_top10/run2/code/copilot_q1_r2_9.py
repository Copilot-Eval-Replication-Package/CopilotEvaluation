
def search(x, seq):
    #assert(is_sorted(seq))
    if len(seq) == 0:
        return 0
    if x <= seq[0]:
        return 0
    if x >= seq[-1]:
        return len(seq)
    left = 0
    right = len(seq) - 1
    while left + 1 < right:
        mid = (left + right) // 2
        if seq[mid] < x:
            left = mid
        else:
            right = mid
    return right

