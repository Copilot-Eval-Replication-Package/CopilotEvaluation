
def search(x, seq):
    if len(seq) == 0:
        return 0
    if x <= seq[0]:
        return 0
    if x >= seq[-1]:
        return len(seq)
    for i in range(1, len(seq)):
        if x <= seq[i]:
            return i

